import json
import platform
import sys
from datetime import datetime

try:
    import psutil
except ImportError:
    print("psutil fehlt. Bitte zuerst setup.bat ausführen.")
    raise SystemExit(2)

from core.config import load_config, LOG_DIR, ensure_dirs
from core.safety import is_admin
from core.system_monitor import get_system_info, sample, top_processes

def safe_sample():
    try:
        return sample()
    except Exception as exc:
        return {"error": str(exc)}

ensure_dirs()
out = {
    "created": datetime.now().isoformat(timespec="seconds"),
    "version": "1.1",
    "python": sys.version,
    "platform": platform.platform(),
    "admin": is_admin(),
    "system": get_system_info(),
    "sample": safe_sample(),
    "top_processes": top_processes(15),
    "config": load_config(),
}
path = LOG_DIR / f"diagnose-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
path.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
print(f"Diagnose erstellt: {path}")
