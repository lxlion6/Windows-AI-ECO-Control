import os
import psutil


def is_windows():
    return os.name == "nt"


def is_admin():
    if not is_windows():
        return False
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def is_protected(proc_name, cfg):
    name = (proc_name or "").strip().lower()
    return name in {x.lower() for x in cfg.get("protected_processes", [])}


def safe_candidates(cfg, foreground_pid=None, min_mib=None, limit=5):
    candidates = []
    threshold = float(min_mib if min_mib is not None else cfg.get("min_app_mib", 750))
    for p in psutil.process_iter(["pid", "name", "memory_info", "username"]):
        try:
            info = p.info
            name = info.get("name") or ""
            rss = info.get("memory_info").rss if info.get("memory_info") else 0
            mem_mib = rss / (1024 ** 2)
            if p.pid in (0, 4) or p.pid == os.getpid() or p.pid == foreground_pid or is_protected(name, cfg):
                continue
            if mem_mib < threshold:
                continue
            candidates.append((mem_mib, p.pid, name))
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    candidates.sort(reverse=True)
    return candidates[:limit]
