import os
import platform
import subprocess
import time
import psutil


def _disk_root():
    return os.environ.get("SystemDrive", "C:") + "\\" if os.name == "nt" else "/"


def get_system_info():
    vm = psutil.virtual_memory()
    try:
        disk = psutil.disk_usage(_disk_root())
    except OSError:
        disk = psutil.disk_usage("/")
    return {
        "os": platform.platform(),
        "hostname": platform.node(),
        "cpu": platform.processor() or "Unbekannte CPU",
        "logical_cpus": psutil.cpu_count(logical=True) or 0,
        "physical_cpus": psutil.cpu_count(logical=False) or 0,
        "ram_total_gb": round(vm.total / (1024 ** 3), 2),
        "disk_total_gb": round(disk.total / (1024 ** 3), 2),
    }


def get_foreground_info():
    """Best-effort Windows foreground window detection. Safe fallback elsewhere."""
    result = {"pid": None, "title": "", "fullscreen": False}
    if os.name != "nt":
        return result
    try:
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return result

        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        result["pid"] = int(pid.value) if pid.value else None

        length = user32.GetWindowTextLengthW(hwnd)
        if length > 0:
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            result["title"] = buf.value

        rect = wintypes.RECT()
        if user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            monitor = user32.MonitorFromWindow(hwnd, 2)

            class MONITORINFO(ctypes.Structure):
                _fields_ = [
                    ("cbSize", wintypes.DWORD),
                    ("rcMonitor", wintypes.RECT),
                    ("rcWork", wintypes.RECT),
                    ("dwFlags", wintypes.DWORD),
                ]

            mi = MONITORINFO()
            mi.cbSize = ctypes.sizeof(MONITORINFO)
            if user32.GetMonitorInfoW(monitor, ctypes.byref(mi)):
                tolerance = 2
                result["fullscreen"] = (
                    abs(rect.left - mi.rcMonitor.left) <= tolerance
                    and abs(rect.top - mi.rcMonitor.top) <= tolerance
                    and abs(rect.right - mi.rcMonitor.right) <= tolerance
                    and abs(rect.bottom - mi.rcMonitor.bottom) <= tolerance
                )
    except Exception:
        pass
    return result


def get_gpu_info():
    """NVIDIA telemetry when nvidia-smi is available; otherwise a neutral fallback."""
    out = {"available": False, "name": "Nicht verfügbar", "load_percent": None, "temp_c": None, "power_w": None}
    try:
        cp = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=name,utilization.gpu,temperature.gpu,power.draw",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )
        if cp.returncode != 0 or not cp.stdout.strip():
            return out
        first = cp.stdout.strip().splitlines()[0]
        parts = [x.strip() for x in first.split(",")]
        if len(parts) >= 4:
            out.update({
                "available": True,
                "name": parts[0],
                "load_percent": float(parts[1]),
                "temp_c": float(parts[2]),
                "power_w": float(parts[3]),
            })
    except (OSError, ValueError, subprocess.SubprocessError):
        pass
    return out


def sample():
    cpu = psutil.cpu_percent(interval=0.25)
    vm = psutil.virtual_memory()
    try:
        disk = psutil.disk_usage(_disk_root())
    except OSError:
        disk = psutil.disk_usage("/")
    fg = get_foreground_info()
    gpu = get_gpu_info()
    return {
        "timestamp": time.time(),
        "cpu_percent": round(cpu, 1),
        "ram_percent": round(vm.percent, 1),
        "ram_available_gb": round(vm.available / (1024 ** 3), 2),
        "ram_total_gb": round(vm.total / (1024 ** 3), 2),
        "disk_percent": round(disk.percent, 1),
        "foreground": fg,
        "gpu": gpu,
    }


def top_processes(limit=10):
    rows = []
    for p in psutil.process_iter(["pid", "name", "memory_percent", "memory_info", "status"]):
        try:
            info = p.info
            rss = info.get("memory_info").rss if info.get("memory_info") else 0
            rows.append({
                "pid": info.get("pid", 0),
                "name": info.get("name") or "?",
                "memory_percent": round(info.get("memory_percent") or 0.0, 2),
                "memory_mib": round(rss / (1024 ** 2), 1),
                "status": info.get("status") or "?",
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    rows.sort(key=lambda x: x["memory_mib"], reverse=True)
    return rows[:limit]
