import logging
from .config import LOG_DIR, ensure_dirs


def setup_logging():
    ensure_dirs()
    path = LOG_DIR / "ki-system-manager.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[logging.FileHandler(path, encoding="utf-8")],
        force=True,
    )
    return path
