@echo off
setlocal
cd /d "%~dp0"
echo KI System Manager - Windows 11 - Einrichtung
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo Python wurde nicht gefunden.
  echo.
  echo Bitte zuerst INSTALLATION.txt oeffnen.
  echo Dort wird die Installation von Python unter Windows 11 Schritt fuer Schritt erklaert.
  echo.
  pause
  exit /b 1
)

echo Pruefe Python-Version...
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)"
if errorlevel 1 (
  echo.
  echo Python 3.11 oder neuer wird benoetigt.
  echo Bitte INSTALLATION.txt oeffnen und eine aktuelle Python-Version installieren.
  echo.
  pause
  exit /b 1
)

for /f "delims=" %%V in ('py -3 --version 2^>^&1') do echo Gefunden: %%V
echo.
echo Erstelle eigene Programmumgebung...
py -3 -m venv .venv
if errorlevel 1 goto :fail

call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto :fail
python -m pip install -r requirements.txt
if errorlevel 1 goto :fail

echo.
echo Einrichtung abgeschlossen. Danach run.bat starten.
pause
exit /b 0

:fail
echo.
echo Einrichtung fehlgeschlagen.
echo Bitte die Ausgabe fotografieren oder diagnose.bat ausfuehren.
pause
exit /b 1
