# KI System Manager - Windows 11 - Version 1.1

Aktualisierte Windows-11-Testversion des KI System Managers. Die Anwendung überwacht CPU, RAM, Datenträger und Prozesse, bewertet die Systembelastung in Stufen 0-4 und kann bei aktivierter Automatik konservative Maßnahmen ausführen.

## Sicherheitsmodell

- Beim ersten Start sind automatische Eingriffe AUS.
- Der Nutzer stellt selbst ein, ab welcher Belastungsstufe eingegriffen wird.
- Der Nutzer stellt unabhängig davon die maximale Aggressivität 0-4 ein.
- Kritische Windows-Prozesse sind in einer Schutzliste.
- Version 1.1 beendet niemals automatisch Prozesse, auch nicht auf Aggressivitätsstufe 4.
- V1.1 verändert nur die Prozesspriorität geeigneter, nicht geschützter Hintergrund-Apps und stellt eigene Änderungen wieder zurück.
- Die aktive Vordergrund-App wird geschützt.
- RAM wird als verfügbar / gesamt angezeigt; die vier RAM-Stufen sind einstellbar.

## Installation auf Windows 11

Für Tester liegt eine ausführliche, schrittweise Anleitung als `INSTALLATION.txt` bei. Für den allerersten Start kann zusätzlich `START-HIER.txt` geöffnet werden.

Kurzfassung:

1. ZIP-Datei vollständig entpacken.
2. Python 3.11 oder neuer installieren.
3. `setup.bat` einmalig doppelklicken.
4. Nach erfolgreicher Einrichtung `run.bat` starten.

Die Oberfläche funktioniert ohne Administratorrechte für das Monitoring. Bestimmte Prozessänderungen können von Windows verweigert werden; das wird abgefangen und protokolliert.

## Diagnose für Tester

Bei einem Fehler `diagnose.bat` starten. Die Diagnose landet unter:

`%USERPROFILE%\\KI-System-Manager-Windows\\logs`

Zusätzlich liegt dort `ki-system-manager.log`.

## Deinstallation

Empfohlen direkt in der Oberfläche:

1. KI System Manager starten.
2. Unten auf `Programm deinstallieren` klicken.
3. Sicherheitshinweis lesen und bestätigen.
4. Das Programm beendet sich und entfernt den Programmordner sowie seine eigenen Benutzerdaten unter `%USERPROFILE%\KI-System-Manager-Windows`.

Falls die Oberfläche nicht mehr startet, `uninstall.bat` im Programmordner doppelklicken und die Abfrage bestätigen. Eine ausführliche Schritt-für-Schritt-Anleitung liegt zusätzlich als `DEINSTALLATION.txt` bei.

Die Deinstallation entfernt **nicht** Python, Windows-Komponenten oder andere Programme.

## Einstellungen

Die Benutzereinstellungen werden gespeichert unter:

`%USERPROFILE%\\KI-System-Manager-Windows\\config.json`

Standard:

- Automatische Eingriffe: AUS
- Eingriff ab Belastungsstufe: 3 (Hohe Belastung)
- Maximale Aggressivität: 2 (Ausgeglichen)

## Hinweis zum Begriff „KI"

Version 1.1 verwendet zunächst eine deterministische Entscheidungs-Engine mit Belastungsstufen und Sicherheitsregeln. Das ist für reproduzierbare Tests absichtlich nachvollziehbar. Lernende/adaptive Logik kann darauf später aufbauen.


## Änderungen in 1.1

Eine leicht verständliche Zusammenfassung liegt als `AENDERUNGEN-V1.1.txt` bei.
