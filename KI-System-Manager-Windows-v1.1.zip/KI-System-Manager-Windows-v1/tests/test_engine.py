import unittest
from core.decision_engine import evaluate, should_act, validate_config

CFG = {
    "auto_actions": True,
    "intervention_threshold": 3,
    "max_aggressiveness": 2,
    "ram_level1_available_gb": 4.0,
    "ram_level2_available_gb": 3.0,
    "ram_level3_available_gb": 2.0,
    "ram_level4_available_gb": 0.75,
    "min_app_mib": 750,
    "cpu_warning_percent": 80,
    "cpu_critical_percent": 95,
    "cpu_responsive_percent": 70,
    "disk_warning_percent": 90,
    "gaming_gpu_percent": 55,
    "gaming_fullscreen_gpu_percent": 35,
    "sustained_gpu_percent": 75,
}


def metrics(ram=8.0, cpu=20, disk=50, gpu=None, fullscreen=False):
    return {
        "ram_available_gb": ram,
        "ram_percent": 40,
        "cpu_percent": cpu,
        "disk_percent": disk,
        "foreground": {"pid": 100, "title": "Test", "fullscreen": fullscreen},
        "gpu": {"available": gpu is not None, "load_percent": gpu},
    }


class EngineTests(unittest.TestCase):
    def test_normal(self):
        d = evaluate(metrics(), CFG)
        self.assertEqual(d.level, 0)
        self.assertFalse(should_act(d, CFG))
        self.assertEqual(d.profile, "ECO")

    def test_ram_level3(self):
        d = evaluate(metrics(ram=1.5), CFG)
        self.assertEqual(d.level, 3)
        self.assertTrue(should_act(d, CFG))

    def test_ram_level4(self):
        d = evaluate(metrics(ram=0.5), CFG)
        self.assertEqual(d.level, 4)

    def test_critical_cpu(self):
        d = evaluate(metrics(ram=8, cpu=97), CFG)
        self.assertEqual(d.level, 4)
        self.assertTrue(should_act(d, CFG))

    def test_auto_off(self):
        cfg = dict(CFG, auto_actions=False)
        d = evaluate(metrics(ram=0.4, cpu=99, disk=95), cfg)
        self.assertFalse(should_act(d, cfg))

    def test_fullscreen_gaming(self):
        d = evaluate(metrics(gpu=45, fullscreen=True), CFG)
        self.assertEqual(d.profile, "GAMING")

    def test_responsive_profile(self):
        d = evaluate(metrics(cpu=75), CFG)
        self.assertEqual(d.profile, "RESPONSIVE")

    def test_config_validation(self):
        validate_config(CFG)
        bad = dict(CFG, ram_level3_available_gb=3.5)
        with self.assertRaises(ValueError):
            validate_config(bad)


if __name__ == "__main__":
    unittest.main()
