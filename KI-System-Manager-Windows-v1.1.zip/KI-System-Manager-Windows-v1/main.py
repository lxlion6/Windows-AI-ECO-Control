import json
import logging
import os
import queue
import subprocess
import threading
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import ttk, messagebox

from core.actions import apply_actions, restore_managed
from core.config import load_config, save_config, DEFAULT_FILE, LOG_DIR
from core.decision_engine import evaluate, should_act, validate_config
from core.logging_setup import setup_logging
from core.safety import is_admin, is_windows
from core.system_monitor import get_system_info, sample, top_processes

LEVEL_TEXT = {
    0: "0 - Nur beobachten",
    1: "1 - Sehr vorsichtig",
    2: "2 - Ausgeglichen",
    3: "3 - Aggressiv",
    4: "4 - Sehr aggressiv",
}

THRESHOLD_TEXT = {
    0: "0 - Immer",
    1: "1 - Frühwarnung",
    2: "2 - Leicht",
    3: "3 - Hohe Belastung",
    4: "4 - Kritisch",
}


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("KI System Manager - Windows 11 - Version 1.1")
        self.geometry("1080x820")
        self.minsize(920, 690)
        self.cfg = load_config()
        self.log_path = setup_logging()
        self.q = queue.Queue()
        self.running = True
        self.last_action_level = -1
        self.dirty = False
        self.vars = {}
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(150, self._drain_queue)
        threading.Thread(target=self._worker, daemon=True).start()

    def _build_ui(self):
        root = ttk.Frame(self, padding=12)
        root.pack(fill="both", expand=True)

        title = ttk.Label(root, text="KI System Manager - Windows 11", font=("Segoe UI", 18, "bold"))
        title.pack(anchor="w")
        ttk.Label(root, text="Version 1.1 · sichere Windows-Portierung des CachyOS-Regelmodells").pack(anchor="w")
        self.platform_label = ttk.Label(root, text="System wird erkannt ...")
        self.platform_label.pack(anchor="w", pady=(2, 10))

        meters = ttk.Frame(root)
        meters.pack(fill="x")
        self.metric_vars = {k: tk.StringVar(value="-") for k in ("Profil", "CPU", "GPU", "RAM", "Status")}
        for i, key in enumerate(("Profil", "CPU", "GPU", "RAM", "Status")):
            box = ttk.LabelFrame(meters, text=key, padding=10)
            box.grid(row=0, column=i, padx=(0 if i == 0 else 4, 4), sticky="nsew")
            ttk.Label(box, textvariable=self.metric_vars[key], font=("Segoe UI", 12, "bold"), wraplength=180).pack()
            meters.columnconfigure(i, weight=1)

        notebook = ttk.Notebook(root)
        notebook.pack(fill="x", pady=12)

        auto_tab = ttk.Frame(notebook, padding=10)
        ram_tab = ttk.Frame(notebook, padding=10)
        hw_tab = ttk.Frame(notebook, padding=10)
        notebook.add(auto_tab, text="Automatik")
        notebook.add(ram_tab, text="Arbeitsspeicher (RAM)")
        notebook.add(hw_tab, text="CPU / GPU / Gaming")

        self.auto_var = tk.BooleanVar(value=bool(self.cfg.get("auto_actions", False)))
        ttk.Checkbutton(auto_tab, text="Automatische Eingriffe aktivieren", variable=self.auto_var,
                        command=self._mark_dirty).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))

        ttk.Label(auto_tab, text="Eingriff ab Belastungsstufe:").grid(row=1, column=0, sticky="w", pady=4)
        self.threshold_var = tk.IntVar(value=int(self.cfg.get("intervention_threshold", 3)))
        threshold = ttk.Scale(auto_tab, from_=0, to=4, orient="horizontal", variable=self.threshold_var,
                              command=lambda _v: self._slider_changed())
        threshold.grid(row=1, column=1, sticky="ew", padx=10)
        self.threshold_label = ttk.Label(auto_tab, text=THRESHOLD_TEXT[self.threshold_var.get()])
        self.threshold_label.grid(row=1, column=2, sticky="w")

        ttk.Label(auto_tab, text="Maximale Aggressivität:").grid(row=2, column=0, sticky="w", pady=4)
        self.aggr_var = tk.IntVar(value=int(self.cfg.get("max_aggressiveness", 2)))
        aggr = ttk.Scale(auto_tab, from_=0, to=4, orient="horizontal", variable=self.aggr_var,
                         command=lambda _v: self._slider_changed())
        aggr.grid(row=2, column=1, sticky="ew", padx=10)
        self.aggr_label = ttk.Label(auto_tab, text=LEVEL_TEXT[self.aggr_var.get()])
        self.aggr_label.grid(row=2, column=2, sticky="w")
        auto_tab.columnconfigure(1, weight=1)

        ttk.Label(
            auto_tab,
            text=("Sicherheitsregel: Die aktive Vordergrund-App sowie kritische Windows-Prozesse werden nicht "
                  "heruntergestuft. Auch Stufe 4 beendet keine Prozesse automatisch."),
            wraplength=900,
        ).grid(row=3, column=0, columnspan=3, sticky="w", pady=(8, 0))

        ttk.Label(ram_tab, text="Wann soll der RAM-Manager reagieren?", font=("Segoe UI", 10, "bold")).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 3))
        ttk.Label(ram_tab, text="Je weniger RAM noch verfügbar ist, desto höher wird die Belastungsstufe.").grid(
            row=1, column=0, columnspan=4, sticky="w", pady=(0, 8))

        ram_fields = [
            ("ram_level1_available_gb", "Stufe 1 ab weniger als (GiB)"),
            ("ram_level2_available_gb", "Stufe 2 ab weniger als (GiB)"),
            ("ram_level3_available_gb", "Stufe 3 ab weniger als (GiB)"),
            ("ram_level4_available_gb", "Stufe 4 ab weniger als (GiB)"),
        ]
        for col, (key, label) in enumerate(ram_fields):
            frame = ttk.Frame(ram_tab)
            frame.grid(row=2, column=col, sticky="ew", padx=(0 if col == 0 else 5, 5))
            ttk.Label(frame, text=label, wraplength=180).pack(anchor="w")
            var = tk.DoubleVar(value=float(self.cfg.get(key)))
            self.vars[key] = var
            spin = ttk.Spinbox(frame, textvariable=var, from_=0.1, to=128, increment=0.05, width=12,
                               command=self._mark_dirty)
            spin.pack(fill="x", pady=(3, 0))
            spin.bind("<KeyRelease>", lambda _e: self._mark_dirty())
            ram_tab.columnconfigure(col, weight=1)

        ttk.Separator(ram_tab).grid(row=3, column=0, columnspan=4, sticky="ew", pady=12)
        ttk.Label(ram_tab, text="App-Erkennung", font=("Segoe UI", 10, "bold")).grid(
            row=4, column=0, columnspan=4, sticky="w")
        ttk.Label(ram_tab, text="Nur Hintergrund-Apps oberhalb dieser RAM-Nutzung kommen für eine Entlastung infrage.").grid(
            row=5, column=0, columnspan=4, sticky="w", pady=(2, 6))
        ttk.Label(ram_tab, text="App gilt als speicherintensiv ab (MiB)").grid(row=6, column=0, sticky="w")
        self.vars["min_app_mib"] = tk.IntVar(value=int(self.cfg.get("min_app_mib", 750)))
        app_spin = ttk.Spinbox(ram_tab, textvariable=self.vars["min_app_mib"], from_=100, to=65536, increment=50,
                               width=14, command=self._mark_dirty)
        app_spin.grid(row=6, column=1, sticky="w")
        app_spin.bind("<KeyRelease>", lambda _e: self._mark_dirty())

        hw_fields = [
            ("cpu_responsive_percent", "Mehr CPU-Last erkannt ab (%)", 10, 100),
            ("gaming_gpu_percent", "Gaming ab GPU-Auslastung (%)", 10, 100),
            ("gaming_fullscreen_gpu_percent", "Vollbild-Gaming ab GPU (%)", 10, 100),
            ("sustained_gpu_percent", "Dauerlast GPU ab (%)", 10, 100),
        ]
        ttk.Label(hw_tab, text="CPU-, GPU- und Gaming-Erkennung", font=("Segoe UI", 10, "bold")).grid(
            row=0, column=0, columnspan=4, sticky="w")
        ttk.Label(hw_tab, text="GPU-Werte werden verwendet, wenn NVIDIA nvidia-smi verfügbar ist.").grid(
            row=1, column=0, columnspan=4, sticky="w", pady=(2, 8))
        for col, (key, label, low, high) in enumerate(hw_fields):
            frame = ttk.Frame(hw_tab)
            frame.grid(row=2, column=col, sticky="ew", padx=(0 if col == 0 else 5, 5))
            ttk.Label(frame, text=label, wraplength=180).pack(anchor="w")
            var = tk.IntVar(value=int(self.cfg.get(key)))
            self.vars[key] = var
            spin = ttk.Spinbox(frame, textvariable=var, from_=low, to=high, increment=1, width=12,
                               command=self._mark_dirty)
            spin.pack(fill="x", pady=(3, 0))
            spin.bind("<KeyRelease>", lambda _e: self._mark_dirty())
            hw_tab.columnconfigure(col, weight=1)

        self.settings_state = tk.StringVar(value="Gespeicherte Einstellungen sind aktiv.")
        actionbar = ttk.Frame(root)
        actionbar.pack(fill="x", pady=(0, 10))
        ttk.Label(actionbar, textvariable=self.settings_state).pack(side="left")
        ttk.Button(actionbar, text="Standardwerte laden", command=self._reset_defaults).pack(side="right")
        ttk.Button(actionbar, text="Speichern", command=self._save_settings).pack(side="right", padx=8)

        paned = ttk.Panedwindow(root, orient="horizontal")
        paned.pack(fill="both", expand=True)

        proc_frame = ttk.LabelFrame(paned, text="RAM-stärkste Prozesse", padding=6)
        self.tree = ttk.Treeview(proc_frame, columns=("name", "pid", "ram", "status"), show="headings", height=12)
        self.tree.heading("name", text="Prozess")
        self.tree.heading("pid", text="PID")
        self.tree.heading("ram", text="RAM (MiB)")
        self.tree.heading("status", text="Status")
        self.tree.column("name", width=190, anchor="w")
        self.tree.column("pid", width=70, anchor="center")
        self.tree.column("ram", width=90, anchor="center")
        self.tree.column("status", width=100, anchor="center")
        self.tree.pack(fill="both", expand=True)
        paned.add(proc_frame, weight=2)

        event_frame = ttk.LabelFrame(paned, text="Entscheidungen / Aktionen", padding=6)
        self.events = tk.Text(event_frame, height=12, width=52, state="disabled", wrap="word")
        self.events.pack(fill="both", expand=True)
        paned.add(event_frame, weight=3)

        footer = ttk.Frame(root)
        footer.pack(fill="x", pady=(10, 0))
        self.admin_var = tk.StringVar(value="Administratorrechte: wird geprüft")
        ttk.Label(footer, textvariable=self.admin_var).pack(side="left")
        ttk.Button(footer, text="Programm deinstallieren", command=self._uninstall).pack(side="right")
        ttk.Button(footer, text="Diagnose erstellen", command=self._diagnose).pack(side="right", padx=8)
        ttk.Button(footer, text="Log-Ordner öffnen", command=self._open_logs).pack(side="right")

    def _slider_changed(self):
        self.threshold_var.set(round(self.threshold_var.get()))
        self.aggr_var.set(round(self.aggr_var.get()))
        self.threshold_label.configure(text=THRESHOLD_TEXT[self.threshold_var.get()])
        self.aggr_label.configure(text=LEVEL_TEXT[self.aggr_var.get()])
        self._mark_dirty()

    def _mark_dirty(self):
        self.dirty = True
        self.settings_state.set("Änderungen noch nicht gespeichert.")

    def _collect_settings(self):
        new_cfg = dict(self.cfg)
        new_cfg["auto_actions"] = bool(self.auto_var.get())
        new_cfg["intervention_threshold"] = int(round(self.threshold_var.get()))
        new_cfg["max_aggressiveness"] = int(round(self.aggr_var.get()))
        for key, var in self.vars.items():
            new_cfg[key] = var.get()
        validate_config(new_cfg)
        return new_cfg

    def _save_settings(self):
        try:
            new_cfg = self._collect_settings()
            save_config(new_cfg)
            self.cfg = new_cfg
            self.dirty = False
            self.settings_state.set("Gespeichert – die neuen Regeln sind jetzt aktiv.")
            self._event("Einstellungen gespeichert und aktiviert.")
        except (ValueError, tk.TclError) as exc:
            messagebox.showerror("Einstellungen prüfen", str(exc))

    def _reset_defaults(self):
        try:
            defaults = json.loads(DEFAULT_FILE.read_text(encoding="utf-8"))
            self.cfg = defaults
            save_config(defaults)
            messagebox.showinfo("Standardwerte", "Standardwerte wurden geladen und aktiviert. Das Programm startet neu.")
            self.running = False
            restore_managed(restore_all=True)
            python = os.sys.executable
            subprocess.Popen([python, str(Path(__file__).resolve())])
            self.destroy()
        except Exception as exc:
            messagebox.showerror("Fehler", f"Standardwerte konnten nicht geladen werden:\n{exc}")

    def _event(self, msg):
        self.events.configure(state="normal")
        self.events.insert("end", msg + "\n")
        self.events.see("end")
        self.events.configure(state="disabled")

    def _worker(self):
        try:
            info = get_system_info()
            self.q.put(("system", info))
            while self.running:
                metrics = sample()
                decision = evaluate(metrics, self.cfg)
                procs = top_processes()
                actions = []
                if should_act(decision, self.cfg):
                    if self.last_action_level < int(self.cfg.get("intervention_threshold", 3)) or decision.level != self.last_action_level:
                        actions = apply_actions(decision, self.cfg, metrics)
                    else:
                        actions = restore_managed(foreground_pid=(metrics.get("foreground") or {}).get("pid"))
                    self.last_action_level = decision.level
                else:
                    actions = restore_managed(restore_all=True)
                    self.last_action_level = decision.level
                self.q.put(("sample", metrics, decision, procs, actions))
                threading.Event().wait(float(self.cfg.get("poll_seconds", 2)))
        except Exception as exc:
            logging.exception("Monitorfehler")
            self.q.put(("error", str(exc)))

    def _drain_queue(self):
        try:
            while True:
                item = self.q.get_nowait()
                if item[0] == "system":
                    i = item[1]
                    self.platform_label.configure(text=f"{i['os']} | {i['ram_total_gb']} GB RAM | {i['logical_cpus']} logische CPUs")
                    if is_windows():
                        self.admin_var.set("Administratorrechte: " + ("Ja" if is_admin() else "Nein (Monitoring funktioniert trotzdem)"))
                    else:
                        self.admin_var.set("Nicht unter Windows gestartet - nur Entwicklung/Diagnose")
                elif item[0] == "sample":
                    _, m, d, procs, actions = item
                    self.metric_vars["Profil"].set(d.profile)
                    self.metric_vars["CPU"].set(f"{m['cpu_percent']} %")
                    gpu = m.get("gpu") or {}
                    if gpu.get("available"):
                        self.metric_vars["GPU"].set(f"{gpu.get('load_percent', 0):.0f} % · {gpu.get('temp_c', 0):.0f} °C")
                    else:
                        self.metric_vars["GPU"].set("Nicht verfügbar")
                    self.metric_vars["RAM"].set(f"{m['ram_available_gb']:.2f} / {m['ram_total_gb']:.2f} GiB frei/gesamt")
                    self.metric_vars["Status"].set(f"Stufe {d.level}: {d.label}")
                    for row in self.tree.get_children():
                        self.tree.delete(row)
                    for p in procs:
                        self.tree.insert("", "end", values=(p["name"], p["pid"], p["memory_mib"], p["status"]))
                    if actions:
                        self._event(f"Stufe {d.level} ({d.reason})")
                        for a in actions:
                            self._event("  " + a)
                elif item[0] == "error":
                    self._event("FEHLER: " + item[1])
        except queue.Empty:
            pass
        if self.running:
            self.after(250, self._drain_queue)

    def _diagnose(self):
        try:
            script = Path(__file__).resolve().parent / "diagnose.py"
            cp = subprocess.run([os.sys.executable, str(script)], capture_output=True, text=True, timeout=20)
            text = (cp.stdout or cp.stderr).strip() or "Diagnose wurde ausgeführt."
            messagebox.showinfo("Diagnose", text)
        except Exception as exc:
            messagebox.showerror("Diagnose", f"Diagnose konnte nicht erstellt werden:\n{exc}")

    def _open_logs(self):
        try:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            if os.name == "nt":
                os.startfile(str(LOG_DIR))
            else:
                messagebox.showinfo("Log-Ordner", str(LOG_DIR))
        except Exception as exc:
            messagebox.showerror("Log-Ordner", str(exc))

    def _uninstall(self):
        if not messagebox.askyesno(
            "KI System Manager deinstallieren",
            "Der KI System Manager wird vollständig entfernt.\n\n"
            "Dabei werden auch die gespeicherten Einstellungen und Protokolle im Benutzerordner gelöscht.\n\n"
            "Möchtest du wirklich fortfahren?",
            icon="warning",
        ):
            return

        uninstall_script = Path(__file__).resolve().parent / "uninstall.bat"
        if not uninstall_script.exists():
            messagebox.showerror("Deinstallation nicht möglich", "Die Datei uninstall.bat wurde nicht gefunden.")
            return

        try:
            restore_managed(restore_all=True)
            subprocess.Popen(
                ["cmd.exe", "/c", "start", "", str(uninstall_script), "--confirmed"],
                cwd=str(uninstall_script.parent),
                creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
            )
            self.running = False
            self.destroy()
        except Exception as exc:
            logging.exception("Deinstallation konnte nicht gestartet werden")
            messagebox.showerror("Fehler", f"Deinstallation konnte nicht gestartet werden:\n{exc}")

    def _on_close(self):
        if self.dirty:
            answer = messagebox.askyesnocancel(
                "Ungespeicherte Änderungen",
                "Die Einstellungen wurden geändert, aber noch nicht gespeichert.\n\nVor dem Beenden speichern?",
            )
            if answer is None:
                return
            if answer:
                self._save_settings()
                if self.dirty:
                    return
        self.running = False
        restore_managed(restore_all=True)
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
