@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Bitte zuerst setup.bat starten.
  pause
  exit /b 1
)
.venv\Scripts\python.exe diagnose.py
pause
