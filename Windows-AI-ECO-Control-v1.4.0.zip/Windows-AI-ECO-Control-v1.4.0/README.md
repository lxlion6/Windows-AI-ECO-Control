# Windows AI ECO Control - Windows 11 - Version 1.4.0

Windows-11-Portierung des aktuellen Windows-AI-ECO-Control-Konzepts. Die Anwendung überwacht CPU, RAM, Datenträger, NVIDIA-GPU (wenn `nvidia-smi` verfügbar ist) und Prozesse. Sie bewertet die Belastung in Stufen 0-4 und kann ausschließlich innerhalb definierter Sicherheitsgrenzen reagieren.

## Neu gegenüber Windows 1.1

- RAM-Stufen klarer: Nutzer stellt nur die GiB-Auslöseschwellen ein; die internen Stärken bleiben sicher fest definiert.
- Erklärende `?`-Hilfen für RAM-Stufen sowie CPU/GPU/Gaming.
- Lokale **KI-Hilfe** über Ollama + `qwen3:1.7b`; sie berät, führt aber keine Befehle aus.
- Optionale **Notfall-KI**: wartet zunächst 30 Sekunden, recherchiert nur auf freigegebenen Fachseiten und akzeptiert keine freien Shell-/PowerShell-/CMD-Befehle.
- Notfallaktionen sind auf im Programm definierte reversible Aktionen begrenzt.
- Feedback an den Entwickler direkt aus der Oberfläche.
- Bestehender Vordergrund-App-Schutz, Prozessschutz, Diagnose und Deinstallation bleiben erhalten.

## Sicherheitsmodell

- Automatische Eingriffe sind beim ersten Start AUS.
- Eingriffsschwelle und maximale Aggressivität bleiben getrennt einstellbar.
- Kritische Windows-Prozesse und die Vordergrund-App sind geschützt.
- Prozesse werden nicht automatisch beendet.
- Eigene Prioritätsänderungen werden wieder zurückgenommen.
- CPU-Temperaturen werden ohne geeignete Telemetrie nicht erfunden oder geschätzt.
- Die Notfall-KI ist standardmäßig AUS.
- Selbst bei aktivierter Notfall-KI werden keine von einem Sprachmodell frei erzeugten Systembefehle ausgeführt.

## Installation

Siehe `START-HIER.txt` und `INSTALLATION.txt`.

Kurzfassung:
1. ZIP vollständig entpacken.
2. Python 3.11 oder neuer installieren.
3. `setup.bat` ausführen.
4. `run.bat` starten.
5. Optional für KI-Hilfe: Ollama installieren und `ollama pull qwen3:1.7b` ausführen.

## Diagnose

`diagnose.bat` oder der Button `Diagnose erstellen`.
Logs: `%USERPROFILE%\Windows-AI-ECO-Control\logs`

## Deinstallation

Über den Button `Programm deinstallieren` oder `uninstall.bat`.
