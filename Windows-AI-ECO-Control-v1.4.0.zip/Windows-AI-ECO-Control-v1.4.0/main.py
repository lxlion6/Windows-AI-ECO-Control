import json
import logging
import os
import queue
import subprocess
import threading
import tkinter as tk
import urllib.parse
import webbrowser
from pathlib import Path
from tkinter import messagebox, ttk

from core.actions import apply_actions, restore_managed
from core.ai_helper import ask_help_ai
from core.config import DEFAULT_FILE, LOG_DIR, load_config, save_config
from core.decision_engine import evaluate, should_act, validate_config
from core.emergency import EmergencyAgent
from core.logging_setup import setup_logging
from core.safety import is_admin, is_windows
from core.system_monitor import get_system_info, sample, top_processes

VERSION = "1.4.0"

LEVEL_TEXT = {
    0: "0 - Nur beobachten",
    1: "1 - Sehr vorsichtig",
    2: "2 - Ausgeglichen",
    3: "3 - Aggressiv",
    4: "4 - Sehr aggressiv",
}

THRESHOLD_TEXT = {
    0: "0 - Immer",
    1: "1 - Frühwarnung",
    2: "2 - Leicht",
    3: "3 - Hohe Belastung",
    4: "4 - Kritisch",
}

RAM_HELP = {
    1: "Stufe 1 – Frühwarnung: sehr leichter Eingriff. Sie gilt unter diesem verfügbaren RAM-Wert, solange Stufe 2 noch nicht erreicht ist.",
    2: "Stufe 2 – Leicht: Hintergrund-Anwendungen werden merklicher entlastet. Sie gilt unter diesem Wert, solange Stufe 3 noch nicht erreicht ist.",
    3: "Stufe 3 – Hoch: freier RAM wird deutlicher geschützt. Sie gilt unter diesem Wert, solange Stufe 4 noch nicht erreicht ist.",
    4: "Stufe 4 – Kritisch: stärkster regulärer Eingriff innerhalb der Sicherheitsgrenzen.",
}


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Windows AI ECO Control - Windows 11 - Version {VERSION}")
        self.geometry("1160x900")
        self.minsize(980, 720)
        self.cfg = load_config()
        self.log_path = setup_logging()
        self.q = queue.Queue()
        self.running = True
        self.last_action_level = -1
        self.dirty = False
        self.vars = {}
        self.last_metrics = {}
        self.last_decision = None
        self.emergency = EmergencyAgent()
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(150, self._drain_queue)
        threading.Thread(target=self._worker, daemon=True).start()

    def _build_ui(self):
        root = ttk.Frame(self, padding=12)
        root.pack(fill="both", expand=True)

        ttk.Label(root, text="Windows AI ECO Control - Windows 11", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(root, text=f"Version {VERSION} · sichere Windows-Portierung des aktuellen CachyOS-Konzepts").pack(anchor="w")
        self.platform_label = ttk.Label(root, text="System wird erkannt ...")
        self.platform_label.pack(anchor="w", pady=(2, 10))

        meters = ttk.Frame(root)
        meters.pack(fill="x")
        self.metric_vars = {k: tk.StringVar(value="-") for k in ("Profil", "CPU", "GPU", "RAM", "Status")}
        for i, key in enumerate(("Profil", "CPU", "GPU", "RAM", "Status")):
            box = ttk.LabelFrame(meters, text=key, padding=10)
            box.grid(row=0, column=i, padx=(0 if i == 0 else 4, 4), sticky="nsew")
            ttk.Label(box, textvariable=self.metric_vars[key], font=("Segoe UI", 12, "bold"), wraplength=190).pack()
            meters.columnconfigure(i, weight=1)

        notebook = ttk.Notebook(root)
        notebook.pack(fill="x", pady=12)
        auto_tab = ttk.Frame(notebook, padding=10)
        ram_tab = ttk.Frame(notebook, padding=10)
        hw_tab = ttk.Frame(notebook, padding=10)
        ai_tab = ttk.Frame(notebook, padding=10)
        notebook.add(auto_tab, text="Automatik")
        notebook.add(ram_tab, text="Arbeitsspeicher (RAM)")
        notebook.add(hw_tab, text="CPU / GPU / Gaming")
        notebook.add(ai_tab, text="KI-Hilfe & Notfall")

        self._build_auto(auto_tab)
        self._build_ram(ram_tab)
        self._build_hw(hw_tab)
        self._build_ai(ai_tab)

        self.settings_state = tk.StringVar(value="Gespeicherte Einstellungen sind aktiv.")
        actionbar = ttk.Frame(root)
        actionbar.pack(fill="x", pady=(0, 10))
        ttk.Label(actionbar, textvariable=self.settings_state).pack(side="left")
        ttk.Button(actionbar, text="Standardwerte laden", command=self._reset_defaults).pack(side="right")
        ttk.Button(actionbar, text="Speichern", command=self._save_settings).pack(side="right", padx=8)

        paned = ttk.Panedwindow(root, orient="horizontal")
        paned.pack(fill="both", expand=True)
        proc_frame = ttk.LabelFrame(paned, text="RAM-stärkste Prozesse", padding=6)
        self.tree = ttk.Treeview(proc_frame, columns=("name", "pid", "ram", "status"), show="headings", height=12)
        for col, title, width in (("name", "Prozess", 190), ("pid", "PID", 70), ("ram", "RAM (MiB)", 90), ("status", "Status", 100)):
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, anchor="w" if col == "name" else "center")
        self.tree.pack(fill="both", expand=True)
        paned.add(proc_frame, weight=2)

        event_frame = ttk.LabelFrame(paned, text="Entscheidungen / Aktionen", padding=6)
        self.events = tk.Text(event_frame, height=12, width=52, state="disabled", wrap="word")
        self.events.pack(fill="both", expand=True)
        paned.add(event_frame, weight=3)

        footer = ttk.Frame(root)
        footer.pack(fill="x", pady=(10, 0))
        self.admin_var = tk.StringVar(value="Administratorrechte werden geprüft ...")
        ttk.Label(footer, textvariable=self.admin_var).pack(side="left")
        ttk.Button(footer, text="Diagnose erstellen", command=self._diagnose).pack(side="right")
        ttk.Button(footer, text="Log-Ordner öffnen", command=self._open_logs).pack(side="right", padx=6)
        ttk.Button(footer, text="Programm deinstallieren", command=self._uninstall).pack(side="right")

    def _build_auto(self, tab):
        self.auto_var = tk.BooleanVar(value=bool(self.cfg.get("auto_actions", False)))
        ttk.Checkbutton(tab, text="Automatische Eingriffe aktivieren", variable=self.auto_var, command=self._mark_dirty).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))

        ttk.Label(tab, text="Eingriff ab Belastungsstufe:").grid(row=1, column=0, sticky="w", pady=4)
        self.threshold_var = tk.IntVar(value=int(self.cfg.get("intervention_threshold", 3)))
        ttk.Scale(tab, from_=0, to=4, orient="horizontal", variable=self.threshold_var, command=lambda _v: self._slider_changed()).grid(row=1, column=1, sticky="ew", padx=10)
        self.threshold_label = ttk.Label(tab, text=THRESHOLD_TEXT[self.threshold_var.get()])
        self.threshold_label.grid(row=1, column=2, sticky="w")

        ttk.Label(tab, text="Maximale Aggressivität:").grid(row=2, column=0, sticky="w", pady=4)
        self.aggr_var = tk.IntVar(value=int(self.cfg.get("max_aggressiveness", 2)))
        ttk.Scale(tab, from_=0, to=4, orient="horizontal", variable=self.aggr_var, command=lambda _v: self._slider_changed()).grid(row=2, column=1, sticky="ew", padx=10)
        self.aggr_label = ttk.Label(tab, text=LEVEL_TEXT[self.aggr_var.get()])
        self.aggr_label.grid(row=2, column=2, sticky="w")
        tab.columnconfigure(1, weight=1)

        ttk.Label(tab, text=(
            "Die vier internen Eingriffsstärken sind sicher voreingestellt. Du bestimmst nur, ab welcher Belastungsstufe "
            "die Automatik beginnt und wie weit sie maximal gehen darf. Die aktive Vordergrund-App und kritische Windows-Prozesse bleiben geschützt."
        ), wraplength=930).grid(row=3, column=0, columnspan=3, sticky="w", pady=(8, 0))

    def _build_ram(self, tab):
        ttk.Label(tab, text="Wann soll der RAM-Manager reagieren?", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, columnspan=4, sticky="w")
        ttk.Label(tab, text="Du stellst nur ein, ab wann eine Stufe beginnt. Wie stark die jeweilige Stufe eingreift, ist sicher voreingestellt.", wraplength=930).grid(row=1, column=0, columnspan=4, sticky="w", pady=(2, 8))

        fields = [
            ("ram_level1_available_gb", "Stufe 1 ab (GiB)", 1),
            ("ram_level2_available_gb", "Stufe 2 ab (GiB)", 2),
            ("ram_level3_available_gb", "Stufe 3 ab (GiB)", 3),
            ("ram_level4_available_gb", "Stufe 4 ab (GiB)", 4),
        ]
        for col, (key, label, level) in enumerate(fields):
            frame = ttk.Frame(tab)
            frame.grid(row=2, column=col, sticky="ew", padx=(0 if col == 0 else 5, 5))
            head = ttk.Frame(frame)
            head.pack(fill="x")
            ttk.Label(head, text=label).pack(side="left")
            ttk.Button(head, text="?", width=2, command=lambda n=level: messagebox.showinfo(f"RAM-Stufe {n}", RAM_HELP[n])).pack(side="right")
            var = tk.DoubleVar(value=float(self.cfg.get(key)))
            self.vars[key] = var
            spin = ttk.Spinbox(frame, textvariable=var, from_=0.1, to=128, increment=0.05, width=12, command=self._mark_dirty)
            spin.pack(fill="x", pady=(3, 0))
            spin.bind("<KeyRelease>", lambda _e: self._mark_dirty())
            tab.columnconfigure(col, weight=1)

        ttk.Separator(tab).grid(row=3, column=0, columnspan=4, sticky="ew", pady=12)
        ttk.Label(tab, text="App-Erkennung", font=("Segoe UI", 10, "bold")).grid(row=4, column=0, columnspan=4, sticky="w")
        ttk.Label(tab, text="Nur Hintergrund-Apps oberhalb dieser RAM-Nutzung kommen für eine Entlastung infrage.").grid(row=5, column=0, columnspan=4, sticky="w", pady=(2, 6))
        ttk.Label(tab, text="App gilt als speicherintensiv ab (MiB)").grid(row=6, column=0, sticky="w")
        self.vars["min_app_mib"] = tk.IntVar(value=int(self.cfg.get("min_app_mib", 750)))
        spin = ttk.Spinbox(tab, textvariable=self.vars["min_app_mib"], from_=100, to=65536, increment=50, width=14, command=self._mark_dirty)
        spin.grid(row=6, column=1, sticky="w")
        spin.bind("<KeyRelease>", lambda _e: self._mark_dirty())

    def _build_hw(self, tab):
        title = ttk.Frame(tab)
        title.grid(row=0, column=0, columnspan=4, sticky="ew")
        ttk.Label(title, text="Prozessor, Grafikkarte und Gaming-Erkennung", font=("Segoe UI", 10, "bold")).pack(side="left")
        ttk.Button(title, text="?", width=2, command=lambda: messagebox.showinfo(
            "CPU / GPU / Gaming",
            "Diese Werte legen fest, ab welcher Auslastung der Manager zwischen ECO, RESPONSIVE und GAMING unterscheidet. NVIDIA-Telemetrie wird nur genutzt, wenn nvidia-smi verfügbar ist. CPU-Temperaturen werden ohne zusätzliche Hardware-Software nicht erfunden oder geschätzt."
        )).pack(side="left", padx=5)
        ttk.Label(tab, text="Die Erkennung beeinflusst die Bewertung; riskante GPU-Power-Limits werden in dieser Windows-Testversion nicht automatisch gesetzt.", wraplength=930).grid(row=1, column=0, columnspan=4, sticky="w", pady=(2, 8))

        fields = [
            ("cpu_responsive_percent", "Mehr CPU-Leistung ab (%)", 10, 100),
            ("gaming_gpu_percent", "Gaming ab GPU (%)", 10, 100),
            ("gaming_fullscreen_gpu_percent", "Vollbild-Gaming ab GPU (%)", 10, 100),
            ("sustained_gpu_percent", "Dauerlast GPU ab (%)", 10, 100),
        ]
        for col, (key, label, low, high) in enumerate(fields):
            frame = ttk.Frame(tab)
            frame.grid(row=2, column=col, sticky="ew", padx=(0 if col == 0 else 5, 5))
            ttk.Label(frame, text=label, wraplength=190).pack(anchor="w")
            var = tk.IntVar(value=int(self.cfg.get(key)))
            self.vars[key] = var
            spin = ttk.Spinbox(frame, textvariable=var, from_=low, to=high, increment=1, width=12, command=self._mark_dirty)
            spin.pack(fill="x", pady=(3, 0))
            spin.bind("<KeyRelease>", lambda _e: self._mark_dirty())
            tab.columnconfigure(col, weight=1)

        ttk.Label(tab, text="Kritische NVIDIA-GPU-Temperatur (°C)").grid(row=3, column=0, sticky="w", pady=(12, 0))
        self.vars["gpu_hot_c"] = tk.IntVar(value=int(self.cfg.get("gpu_hot_c", 84)))
        spin = ttk.Spinbox(tab, textvariable=self.vars["gpu_hot_c"], from_=50, to=100, increment=1, width=12, command=self._mark_dirty)
        spin.grid(row=3, column=1, sticky="w", pady=(12, 0))
        spin.bind("<KeyRelease>", lambda _e: self._mark_dirty())

    def _build_ai(self, tab):
        ttk.Label(tab, text="Lokale KI-Hilfe", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(tab, text="Die Hilfe nutzt lokal Ollama mit Qwen3. Sie erklärt Probleme, führt aber selbst keine Befehle aus.", wraplength=930).grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 6))
        self.chat_log = tk.Text(tab, height=9, wrap="word", state="disabled")
        self.chat_log.grid(row=2, column=0, columnspan=3, sticky="nsew")
        self.chat_entry = tk.Text(tab, height=3, wrap="word")
        self.chat_entry.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        ttk.Button(tab, text="Senden", command=self._send_chat).grid(row=3, column=2, sticky="ns", padx=(6, 0), pady=(6, 0))
        self.chat_entry.bind("<Control-Return>", lambda _e: self._send_chat())
        tab.columnconfigure(0, weight=1)
        tab.columnconfigure(1, weight=1)

        ttk.Separator(tab).grid(row=4, column=0, columnspan=3, sticky="ew", pady=12)
        ttk.Label(tab, text="Notfall-KI", font=("Segoe UI", 10, "bold")).grid(row=5, column=0, sticky="w")
        ttk.Button(tab, text="?", width=2, command=lambda: messagebox.showinfo(
            "Notfall-KI",
            "Die Notfall-KI wartet bei einem kritischen Zustand zunächst 30 Sekunden. Erst wenn die normalen Regeln nicht ausreichen, recherchiert sie auf freigegebenen Fachseiten. Unter Windows darf sie keine freien Shell-Befehle ausführen. Zulässig sind nur bereits im Programm definierte, reversible Aktionen."
        )).grid(row=5, column=1, sticky="w")
        self.emergency_var = tk.BooleanVar(value=bool(self.cfg.get("emergency_ai_enabled", False)))
        ttk.Checkbutton(tab, text="Notfall-KI aktivieren", variable=self.emergency_var, command=self._mark_dirty).grid(row=6, column=0, columnspan=2, sticky="w", pady=(4, 0))
        self.emergency_status = tk.StringVar(value="Status: deaktiviert")
        ttk.Label(tab, textvariable=self.emergency_status, wraplength=930).grid(row=7, column=0, columnspan=3, sticky="w", pady=(3, 0))

        ttk.Separator(tab).grid(row=8, column=0, columnspan=3, sticky="ew", pady=12)
        ttk.Label(tab, text="Feedback an Entwickler", font=("Segoe UI", 10, "bold")).grid(row=9, column=0, columnspan=3, sticky="w")
        ttk.Label(tab, text="Problem oder Verbesserungsvorschlag über ein externes Bestätigungsformular senden.").grid(row=10, column=0, columnspan=3, sticky="w")
        ttk.Button(tab, text="Feedback-Formular öffnen", command=self._feedback).grid(row=11, column=0, sticky="w", pady=(5, 0))

    def _slider_changed(self):
        self.threshold_var.set(int(round(self.threshold_var.get())))
        self.aggr_var.set(int(round(self.aggr_var.get())))
        self.threshold_label.configure(text=THRESHOLD_TEXT[self.threshold_var.get()])
        self.aggr_label.configure(text=LEVEL_TEXT[self.aggr_var.get()])
        self._mark_dirty()

    def _mark_dirty(self):
        self.dirty = True
        self.settings_state.set("Geändert – noch nicht gespeichert.")

    def _collect_settings(self):
        new_cfg = dict(self.cfg)
        new_cfg["auto_actions"] = bool(self.auto_var.get())
        new_cfg["intervention_threshold"] = int(self.threshold_var.get())
        new_cfg["max_aggressiveness"] = int(self.aggr_var.get())
        new_cfg["emergency_ai_enabled"] = bool(self.emergency_var.get())
        for key, var in self.vars.items():
            new_cfg[key] = var.get()
        validate_config(new_cfg)
        return new_cfg

    def _save_settings(self):
        try:
            new_cfg = self._collect_settings()
            save_config(new_cfg)
            self.cfg = new_cfg
            self.dirty = False
            self.settings_state.set("Gespeichert – die neuen Regeln sind jetzt aktiv.")
            self._event("Einstellungen gespeichert und aktiviert.")
        except (ValueError, tk.TclError) as exc:
            messagebox.showerror("Einstellungen prüfen", str(exc))

    def _reset_defaults(self):
        try:
            defaults = json.loads(DEFAULT_FILE.read_text(encoding="utf-8"))
            save_config(defaults)
            messagebox.showinfo("Standardwerte", "Standardwerte wurden geladen. Das Programm startet neu.")
            self.running = False
            restore_managed(restore_all=True)
            subprocess.Popen([os.sys.executable, str(Path(__file__).resolve())])
            self.destroy()
        except Exception as exc:
            messagebox.showerror("Fehler", f"Standardwerte konnten nicht geladen werden:\n{exc}")

    def _event(self, msg):
        self.events.configure(state="normal")
        self.events.insert("end", msg + "\n")
        self.events.see("end")
        self.events.configure(state="disabled")

    def _worker(self):
        try:
            self.q.put(("system", get_system_info()))
            while self.running:
                metrics = sample()
                decision = evaluate(metrics, self.cfg)
                procs = top_processes()
                actions = []
                if should_act(decision, self.cfg):
                    if self.last_action_level < int(self.cfg.get("intervention_threshold", 3)) or decision.level != self.last_action_level:
                        actions = apply_actions(decision, self.cfg, metrics)
                    else:
                        actions = restore_managed(foreground_pid=(metrics.get("foreground") or {}).get("pid"))
                else:
                    actions = restore_managed(restore_all=True)
                self.last_action_level = decision.level

                emergency_state = self.emergency.evaluate(metrics, self.cfg)
                if (
                    self.cfg.get("auto_actions")
                    and int(self.cfg.get("max_aggressiveness", 2)) >= 4
                    and emergency_state.get("action") == "lower_background_priority"
                ):
                    actions += apply_actions(type("ED", (), {"level": 4})(), dict(self.cfg, max_aggressiveness=4), metrics)
                elif emergency_state.get("action") == "restore_managed":
                    actions += restore_managed(restore_all=True)

                self.q.put(("sample", metrics, decision, procs, actions, emergency_state))
                threading.Event().wait(float(self.cfg.get("poll_seconds", 2)))
        except Exception as exc:
            logging.exception("Monitorfehler")
            self.q.put(("error", str(exc)))

    def _drain_queue(self):
        try:
            while True:
                item = self.q.get_nowait()
                if item[0] == "system":
                    i = item[1]
                    self.platform_label.configure(text=f"{i['os']} | {i['ram_total_gb']} GB RAM | {i['logical_cpus']} logische CPUs")
                    self.admin_var.set("Administratorrechte: " + ("Ja" if is_admin() else "Nein (Monitoring funktioniert trotzdem)")) if is_windows() else self.admin_var.set("Nicht unter Windows gestartet - nur Entwicklung/Diagnose")
                elif item[0] == "sample":
                    _, m, d, procs, actions, emergency_state = item
                    self.last_metrics = m
                    self.last_decision = d
                    self.metric_vars["Profil"].set(d.profile)
                    self.metric_vars["CPU"].set(f"{m['cpu_percent']} %")
                    gpu = m.get("gpu") or {}
                    self.metric_vars["GPU"].set(f"{gpu.get('load_percent', 0):.0f} % · {gpu.get('temp_c', 0):.0f} °C" if gpu.get("available") else "Nicht verfügbar")
                    self.metric_vars["RAM"].set(f"{m['ram_available_gb']:.2f} / {m['ram_total_gb']:.2f} GiB frei/gesamt")
                    self.metric_vars["Status"].set(f"Stufe {d.level}: {d.label}")
                    self.emergency_status.set(f"Status: {emergency_state.get('status', '?')} – {emergency_state.get('message', '')}")
                    for row in self.tree.get_children(): self.tree.delete(row)
                    for p in procs: self.tree.insert("", "end", values=(p["name"], p["pid"], p["memory_mib"], p["status"]))
                    if actions:
                        self._event(f"Stufe {d.level} ({d.reason})")
                        for a in actions: self._event("  " + a)
                elif item[0] == "chat":
                    self._chat_add("KI", item[1])
                elif item[0] == "error":
                    self._event("FEHLER: " + item[1])
        except queue.Empty:
            pass
        if self.running:
            self.after(250, self._drain_queue)

    def _chat_add(self, prefix, text):
        self.chat_log.configure(state="normal")
        self.chat_log.insert("end", f"{prefix}: {text}\n\n")
        self.chat_log.see("end")
        self.chat_log.configure(state="disabled")

    def _send_chat(self):
        text = self.chat_entry.get("1.0", "end").strip()
        if not text: return
        self.chat_entry.delete("1.0", "end")
        self._chat_add("Du", text)
        self._chat_add("KI", "denkt nach ...")
        context = {
            "metrics": self.last_metrics,
            "decision": vars(self.last_decision) if self.last_decision else {},
            "emergency": self.emergency.last_state,
        }
        def work():
            try:
                ans = ask_help_ai(text, context, self.cfg.get("ai_model", "qwen3:1.7b"))
                self.q.put(("chat", ans))
            except Exception as exc:
                self.q.put(("chat", "Fehler: " + str(exc)))
        threading.Thread(target=work, daemon=True).start()

    def _drain_chat_queue(self):
        stash = []
        try:
            while True:
                item = self.q.get_nowait()
                if item[0] == "chat":
                    self._chat_add("KI", item[1])
                else:
                    stash.append(item)
        except queue.Empty:
            pass
        for item in stash: self.q.put(item)

    def _feedback(self):
        params = urllib.parse.urlencode({
            "subject": "Windows AI ECO Control – Feedback",
            "message": "[Windows 11 Testversion]\n\nBitte hier Problem oder Verbesserungsvorschlag eintragen."
        })
        webbrowser.open("https://formsubmit.co/el/sawema/?" + params)

    def _diagnose(self):
        try:
            script = Path(__file__).resolve().parent / "diagnose.py"
            cp = subprocess.run([os.sys.executable, str(script)], capture_output=True, text=True, timeout=20)
            messagebox.showinfo("Diagnose", (cp.stdout or cp.stderr).strip() or "Diagnose wurde ausgeführt.")
        except Exception as exc:
            messagebox.showerror("Diagnose", f"Diagnose konnte nicht erstellt werden:\n{exc}")

    def _open_logs(self):
        try:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            os.startfile(str(LOG_DIR)) if os.name == "nt" else messagebox.showinfo("Log-Ordner", str(LOG_DIR))
        except Exception as exc:
            messagebox.showerror("Log-Ordner", str(exc))

    def _uninstall(self):
        if not messagebox.askyesno("Windows AI ECO Control deinstallieren", "Der Windows AI ECO Control wird vollständig entfernt. Eigene Einstellungen und Logs werden ebenfalls gelöscht. Fortfahren?", icon="warning"):
            return
        script = Path(__file__).resolve().parent / "uninstall.bat"
        if not script.exists():
            messagebox.showerror("Deinstallation nicht möglich", "uninstall.bat wurde nicht gefunden.")
            return
        try:
            restore_managed(restore_all=True)
            subprocess.Popen(["cmd.exe", "/c", "start", "", str(script), "--confirmed"], cwd=str(script.parent), creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
            self.running = False
            self.destroy()
        except Exception as exc:
            messagebox.showerror("Fehler", f"Deinstallation konnte nicht gestartet werden:\n{exc}")

    def _on_close(self):
        if self.dirty:
            answer = messagebox.askyesnocancel("Ungespeicherte Änderungen", "Einstellungen wurden geändert, aber noch nicht gespeichert. Vor dem Beenden speichern?")
            if answer is None: return
            if answer:
                self._save_settings()
                if self.dirty: return
        self.running = False
        restore_managed(restore_all=True)
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
