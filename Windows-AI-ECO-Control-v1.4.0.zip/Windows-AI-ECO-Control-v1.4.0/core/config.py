import json
import shutil
from pathlib import Path

APP_DIR = Path.home() / "Windows-AI-ECO-Control"
LEGACY_APP_DIR = Path.home() / "KI-System-Manager-Windows"
CONFIG_FILE = APP_DIR / "config.json"
LOG_DIR = APP_DIR / "logs"
DEFAULT_FILE = Path(__file__).resolve().parents[1] / "config" / "default.json"


def ensure_dirs():
    # Einstellungen der bisherigen Testversion beim ersten Start übernehmen.
    if not APP_DIR.exists() and LEGACY_APP_DIR.exists():
        try:
            shutil.copytree(LEGACY_APP_DIR, APP_DIR)
        except OSError:
            pass
    APP_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)


def load_config():
    ensure_dirs()
    with DEFAULT_FILE.open("r", encoding="utf-8") as f:
        defaults = json.load(f)
    if CONFIG_FILE.exists():
        try:
            with CONFIG_FILE.open("r", encoding="utf-8") as f:
                user = json.load(f)
            defaults.update(user)
        except (OSError, json.JSONDecodeError):
            pass
    return defaults


def save_config(cfg):
    ensure_dirs()
    tmp = CONFIG_FILE.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    tmp.replace(CONFIG_FILE)
