import atexit
import logging
import os
import psutil
from .safety import is_protected, safe_candidates

log = logging.getLogger("windows-ai-eco-control")
_managed = {}


def _restore_pid(pid):
    old = _managed.pop(pid, None)
    if old is None:
        return None
    try:
        p = psutil.Process(pid)
        p.nice(old)
        return f"Priorität wiederhergestellt: {p.name()} (PID {pid})"
    except (psutil.NoSuchProcess, psutil.AccessDenied, OSError):
        return None


def restore_managed(foreground_pid=None, restore_all=False):
    messages = []
    for pid in list(_managed):
        if restore_all or pid == foreground_pid:
            msg = _restore_pid(pid)
            if msg:
                messages.append(msg)
                log.info(msg)
    return messages


def _cleanup():
    restore_managed(restore_all=True)


atexit.register(_cleanup)


def apply_actions(decision, cfg, metrics=None):
    """Conservative Windows V1.1 actions. Never terminates processes automatically."""
    if os.name != "nt":
        return ["Keine Windows-Eingriffe: Programm läuft nicht unter Windows."]

    aggressiveness = max(0, min(4, int(cfg.get("max_aggressiveness", 2))))
    effective = min(int(decision.level), aggressiveness)
    if effective == 0:
        return ["Aggressivität 0: nur Überwachung."]

    foreground_pid = None
    if metrics:
        foreground_pid = (metrics.get("foreground") or {}).get("pid")
    messages = restore_managed(foreground_pid=foreground_pid)

    counts = {1: 1, 2: 2, 3: 3, 4: 5}
    target = psutil.BELOW_NORMAL_PRIORITY_CLASS if effective <= 2 else psutil.IDLE_PRIORITY_CLASS
    candidates = safe_candidates(
        cfg,
        foreground_pid=foreground_pid,
        min_mib=float(cfg.get("min_app_mib", 750)),
        limit=counts[effective],
    )
    if not candidates:
        return messages + ["Keine sichere Hintergrund-App oberhalb der RAM-Grenze gefunden."]

    for mem_mib, pid, name in candidates:
        if is_protected(name, cfg):
            continue
        try:
            proc = psutil.Process(pid)
            old = proc.nice()
            if old in (psutil.HIGH_PRIORITY_CLASS, psutil.REALTIME_PRIORITY_CLASS):
                continue
            if pid not in _managed:
                _managed[pid] = old
            if old != target:
                proc.nice(target)
                msg = f"Hintergrund-App entlastet: {name} (PID {pid}, {mem_mib:.0f} MiB)"
                messages.append(msg)
                log.info(msg)
        except (psutil.NoSuchProcess, psutil.AccessDenied, OSError) as exc:
            log.warning("Aktion übersprungen für PID %s: %s", pid, exc)

    if effective >= 4:
        messages.append("Sehr aggressiv: Sicherheitsgrenze bleibt aktiv – keine Prozesse werden beendet.")
    return messages or ["Keine zulässige Optimierung durchgeführt."]
