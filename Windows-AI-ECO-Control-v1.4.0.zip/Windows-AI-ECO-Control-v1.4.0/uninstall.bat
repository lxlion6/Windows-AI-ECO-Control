@echo off
setlocal EnableExtensions
chcp 65001 >nul

title Windows AI ECO Control - Deinstallation
set "INSTALL_DIR=%~dp0"
set "USER_DATA=%USERPROFILE%\Windows-AI-ECO-Control"
set "LEGACY_USER_DATA=%USERPROFILE%\KI-System-Manager-Windows"

if /I "%~1"=="--confirmed" goto uninstall

echo ============================================================
echo   Windows AI ECO Control - Windows 11 - Deinstallation
echo ============================================================
echo.
echo Es werden entfernt:
echo   1. Der Programmordner:
echo      %INSTALL_DIR%
echo   2. Einstellungen und Protokolle:
echo      %USER_DATA%
echo   3. Falls vorhanden, Daten der frueheren Testversion:
echo      %LEGACY_USER_DATA%
echo.
echo Diese Aktion kann nicht automatisch rueckgaengig gemacht werden.
echo.
choice /C JN /N /M "Moechtest du den Windows AI ECO Control wirklich deinstallieren? [J/N]: "
if errorlevel 2 goto cancelled

:uninstall
echo.
echo Deinstallation wird vorbereitet ...

rem Benutzerdaten entfernen. Fehler werden angezeigt, aber die Deinstallation laeuft weiter.
if exist "%USER_DATA%" (
    rmdir /S /Q "%USER_DATA%" 2>nul
)
if exist "%LEGACY_USER_DATA%" (
    rmdir /S /Q "%LEGACY_USER_DATA%" 2>nul
)

rem Dieses Skript kann seinen eigenen Ordner nicht direkt loeschen.
rem Deshalb wird ein temporaeres Hilfsskript erstellt, das nach kurzer Pause aufraeumt.
set "CLEANUP=%TEMP%\windows_ai_eco_control_cleanup_%RANDOM%_%RANDOM%.cmd"
>"%CLEANUP%" echo @echo off
>>"%CLEANUP%" echo timeout /t 2 /nobreak ^>nul
>>"%CLEANUP%" echo rmdir /S /Q "%INSTALL_DIR%" 2^>nul
>>"%CLEANUP%" echo echo.
>>"%CLEANUP%" echo echo Windows AI ECO Control wurde deinstalliert.
>>"%CLEANUP%" echo timeout /t 3 /nobreak ^>nul
>>"%CLEANUP%" echo del /F /Q "%%~f0" ^>nul 2^>^&1

start "" /min cmd.exe /c ""%CLEANUP%""
exit /b 0

:cancelled
echo.
echo Deinstallation abgebrochen. Es wurde nichts geloescht.
pause
exit /b 0
