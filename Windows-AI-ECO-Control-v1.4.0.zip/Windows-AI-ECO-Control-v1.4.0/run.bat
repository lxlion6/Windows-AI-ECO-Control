@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\pythonw.exe (
  echo Bitte zuerst setup.bat starten.
  pause
  exit /b 1
)
start "Windows AI ECO Control" .venv\Scripts\pythonw.exe main.py
