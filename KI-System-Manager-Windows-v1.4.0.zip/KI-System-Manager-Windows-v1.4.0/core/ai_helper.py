import json
import urllib.error
import urllib.request

OLLAMA_URL = "http://127.0.0.1:11434/api/generate"


def ask_help_ai(message, system_context, model="qwen3:1.7b"):
    message = str(message or "").strip()
    if not message:
        raise ValueError("Keine Nachricht eingegeben.")
    if len(message) > 3000:
        raise ValueError("Die Nachricht ist zu lang. Maximal 3000 Zeichen.")

    prompt = f"""
Du bist die integrierte Hilfe-KI des KI System Managers fuer Windows 11.

AUFGABE:
Hilf einem Anfaenger bei Problemen mit dem KI System Manager oder Windows 11.
Antworte auf Deutsch, kurz, verstaendlich und schrittweise.

SICHERHEIT:
- Fuehre niemals selbst Befehle aus.
- Gib keine destruktiven oder riskanten Befehle als erste Loesung.
- Bevorzuge ungefaehrliche Pruefungen und reversible Schritte.
- Wenn du einen Windows-Befehl empfiehlst, erklaere kurz, was er macht.
- Wenn Systemdaten fehlen, sage klar, welche Information benoetigt wird.
- Erfinde keine Systemzustaende, die nicht in den Daten stehen.
- Bei kritischem Hardware- oder Datenrisiko sollst du empfehlen, keine weiteren Aenderungen vorzunehmen.

AKTUELLER SYSTEMSTATUS:
{json.dumps(system_context, ensure_ascii=False)}

FRAGE DES ANWENDERS:
{message}
"""
    payload = json.dumps({
        "model": model,
        "prompt": prompt,
        "stream": False,
        "keep_alive": 0,
        "options": {"temperature": 0.2},
    }).encode("utf-8")
    req = urllib.request.Request(
        OLLAMA_URL,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=90) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError) as exc:
        raise RuntimeError(
            "Die lokale KI ist nicht erreichbar. Bitte pruefen, ob Ollama laeuft und das Modell installiert ist."
        ) from exc
    answer = str(data.get("response", "")).strip()
    if not answer:
        raise RuntimeError("Die lokale KI hat keine Antwort geliefert.")
    return answer
