from dataclasses import dataclass


@dataclass(frozen=True)
class Decision:
    level: int
    label: str
    reason: str
    profile: str


LABELS = {
    0: "Optimal",
    1: "Frühwarnung",
    2: "Leicht",
    3: "Hoch",
    4: "Kritisch",
}


def _ram_level(available_gb, cfg):
    l1 = float(cfg.get("ram_level1_available_gb", 4.0))
    l2 = float(cfg.get("ram_level2_available_gb", 3.0))
    l3 = float(cfg.get("ram_level3_available_gb", 2.0))
    l4 = float(cfg.get("ram_level4_available_gb", 0.75))
    if available_gb < l4:
        return 4
    if available_gb < l3:
        return 3
    if available_gb < l2:
        return 2
    if available_gb < l1:
        return 1
    return 0


def _cpu_level(value, warning, critical):
    if value >= critical:
        return 4
    if value >= warning:
        return 3
    if value >= max(0, warning - 10):
        return 2
    if value >= max(0, warning - 20):
        return 1
    return 0


def _profile(metrics, cfg):
    cpu = float(metrics.get("cpu_percent", 0))
    gpu = metrics.get("gpu") or {}
    gpu_load = gpu.get("load_percent")
    fg = metrics.get("foreground") or {}

    if gpu_load is not None:
        if fg.get("fullscreen") and gpu_load >= float(cfg.get("gaming_fullscreen_gpu_percent", 35)):
            return "GAMING"
        if gpu_load >= float(cfg.get("sustained_gpu_percent", 75)):
            return "GAMING"
        if gpu_load >= float(cfg.get("gaming_gpu_percent", 55)) and cpu >= 25:
            return "GAMING"

    if cpu >= float(cfg.get("cpu_responsive_percent", 70)):
        return "RESPONSIVE"
    return "ECO"


def evaluate(metrics, cfg):
    ram = _ram_level(float(metrics.get("ram_available_gb", 0)), cfg)
    cpu = _cpu_level(
        float(metrics.get("cpu_percent", 0)),
        float(cfg.get("cpu_warning_percent", 80)),
        float(cfg.get("cpu_critical_percent", 95)),
    )
    disk = 3 if float(metrics.get("disk_percent", 0)) >= float(cfg.get("disk_warning_percent", 90)) else 0
    level = max(ram, cpu, disk)
    causes = []
    if ram == level and level > 0:
        causes.append(f"RAM verfügbar {metrics.get('ram_available_gb', 0):.2f} GiB")
    if cpu == level and level > 0:
        causes.append(f"CPU {metrics.get('cpu_percent', 0):.1f}%")
    if disk == level and level > 0:
        causes.append(f"Datenträger {metrics.get('disk_percent', 0):.1f}%")
    reason = ", ".join(causes) if causes else "System im Normalbereich"
    return Decision(level, LABELS[level], reason, _profile(metrics, cfg))


def should_act(decision, cfg):
    return bool(cfg.get("auto_actions", False)) and decision.level >= int(cfg.get("intervention_threshold", 3))


def validate_config(cfg):
    l1 = float(cfg.get("ram_level1_available_gb", 4.0))
    l2 = float(cfg.get("ram_level2_available_gb", 3.0))
    l3 = float(cfg.get("ram_level3_available_gb", 2.0))
    l4 = float(cfg.get("ram_level4_available_gb", 0.75))
    if not (0.1 <= l4 < l3 < l2 < l1 <= 128):
        raise ValueError("RAM-Stufen müssen gelten: Stufe 4 < Stufe 3 < Stufe 2 < Stufe 1.")
    if not 100 <= float(cfg.get("min_app_mib", 750)) <= 65536:
        raise ValueError("Die App-RAM-Grenze muss zwischen 100 und 65536 MiB liegen.")
    if not 10 <= float(cfg.get("cpu_responsive_percent", 70)) <= 100:
        raise ValueError("Die CPU-Schwelle muss zwischen 10 und 100 % liegen.")
    if not 10 <= float(cfg.get("gaming_gpu_percent", 55)) <= 100:
        raise ValueError("Die GPU-Gaming-Schwelle muss zwischen 10 und 100 % liegen.")
    if not 10 <= float(cfg.get("gaming_fullscreen_gpu_percent", 35)) <= 100:
        raise ValueError("Die Vollbild-GPU-Schwelle muss zwischen 10 und 100 % liegen.")
    if not 10 <= float(cfg.get("sustained_gpu_percent", 75)) <= 100:
        raise ValueError("Die GPU-Dauerlast-Schwelle muss zwischen 10 und 100 % liegen.")
    if not 0 <= int(cfg.get("intervention_threshold", 3)) <= 4:
        raise ValueError("Die Eingriffsschwelle muss zwischen 0 und 4 liegen.")
    if not 0 <= int(cfg.get("max_aggressiveness", 2)) <= 4:
        raise ValueError("Die maximale Aggressivität muss zwischen 0 und 4 liegen.")
    if not 50 <= float(cfg.get("gpu_hot_c", 84)) <= 100:
        raise ValueError("Die kritische GPU-Temperatur muss zwischen 50 und 100 °C liegen.")
    if not 5 <= float(cfg.get("emergency_persist_seconds", 30)) <= 600:
        raise ValueError("Die Notfall-Wartezeit muss zwischen 5 und 600 Sekunden liegen.")
    if not 30 <= float(cfg.get("emergency_cooldown_seconds", 300)) <= 3600:
        raise ValueError("Die Notfall-Pause muss zwischen 30 und 3600 Sekunden liegen.")
