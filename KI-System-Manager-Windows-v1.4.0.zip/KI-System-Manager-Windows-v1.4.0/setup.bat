@echo off
setlocal
cd /d "%~dp0"
echo KI System Manager - Windows 11 - Einrichtung v1.4.0
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo Python wurde nicht gefunden.
  echo Bitte zuerst INSTALLATION.txt oeffnen.
  pause
  exit /b 1
)

py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)"
if errorlevel 1 (
  echo Python 3.11 oder neuer wird benoetigt.
  echo Bitte INSTALLATION.txt oeffnen und Python aktualisieren.
  pause
  exit /b 1
)

for /f "delims=" %%V in ('py -3 --version 2^>^&1') do echo Gefunden: %%V
echo.
echo Erstelle eigene Programmumgebung...
py -3 -m venv .venv
if errorlevel 1 goto :fail
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto :fail
python -m pip install -r requirements.txt
if errorlevel 1 goto :fail

echo.
where ollama >nul 2>nul
if errorlevel 1 (
  echo HINWEIS: Ollama wurde nicht gefunden.
  echo Der System Manager funktioniert trotzdem. Nur KI-Hilfe und Notfall-KI stehen dann nicht zur Verfuegung.
  echo Die optionale Ollama-Einrichtung steht in INSTALLATION.txt.
) else (
  echo Ollama wurde gefunden. Pruefe lokales KI-Modell...
  ollama list | findstr /i "qwen3:1.7b" >nul 2>nul
  if errorlevel 1 (
    echo Qwen3 1.7B ist noch nicht installiert.
    echo Anleitung: INSTALLATION.txt - Abschnitt "Optionale lokale KI".
  ) else (
    echo Lokale KI Qwen3 1.7B ist vorhanden.
  )
)

echo.
echo Einrichtung abgeschlossen. Danach run.bat starten.
pause
exit /b 0

:fail
echo.
echo Einrichtung fehlgeschlagen.
echo Bitte die Ausgabe fotografieren oder diagnose.bat ausfuehren.
pause
exit /b 1
